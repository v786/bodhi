<!--Code Indented-->

<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7555171924828663",
    enable_page_level_ads: true
  });
</script>
<!-- <script src="https://www.gstatic.com/firebasejs/3.4.1/firebase.js"></script> -->
<!-- <script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCbhHVkUz3iBF7wrndkIaN28p7uGrw1yMU",
    authDomain: "lifo-6fbe4.firebaseapp.com",
    databaseURL: "https://lifo-6fbe4.firebaseio.com",
    storageBucket: "lifo-6fbe4.appspot.com",
    messagingSenderId: "807517640325"
  };
  firebase.initializeApp(config);
</script> -->

<!--- basic page needs
================================================== -->
<meta charset="utf-8">
<title>Aurganon '17</title>
<meta name="description" content="">
<meta name="author" content="">

<!-- mobile specific metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->

<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/vendor.css">
<style>

#cta {
    background: #034e4a;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding-top: 7rem;
    padding-bottom: 0;
    text-align: center;
}
</style>
<!-- script
================================================== -->
<script src="js/jquery.easing.min.js"></script>
<script src="js/scrolling-nav.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/particles.js"></script>
<script src="js/particles.min.js"></script>
<script src="js/materialize.js"></script>
<script>

$(document).ready(function() {
$(".text").hide()

});
function getResults(elem) {
elem.checked && elem.value == "Show" ? $(".text").show() : $(".text").hide();
};
</script>

<!-- favicons
================================================== -->
<link rel="icon" type="image/png" href="images/logo.ico">
<!--style>
.fixed-nav {
position: fixed;
top: 0;
left: 0;
width: 100%;
background-color: rgba(255,255,255,.8) ;

white-space: nowrap;
height: 50px;
box-sizing: border-box;
padding: 10px;
box-shadow: 0px 3px 6px rgba(0,0,0,0.16),0px 3px 6px rgba(0,0,0,0.23);
}

.fixed-nav ul, .fixed-nav li {
display:inline;
}

.fixed-nav a {
text-decoration: none;
text-transform: uppercase;
padding: 17px 10px;
color: #333;
font-family: arial;
}

.fixed-nav a:hover {
background-color: #000;
color: #eee;
}

.fixed-nav ul {
padding:0;
}
.fixed-nav img {
vertical-align: middle;
}
main {margin-top:55px;}
</style>


</head-->

<body id="top">

<!-- header
================================================== -->
<!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/57d29d15311d6c5be06348be/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
<style>
.navbar {
   margin-bottom:0px;
}	
input{
    margin-bottom: 1rem;
}
input[type="email"], input[type="number"], input[type="search"], input[type="text"], input[type="tel"], input[type="url"], input[type="password"], textarea, select {
    display: block;
    height: 4rem;
    padding: 1.5rem 2rem;
    border: none;
    border-bottom: 1px solid rgba(17, 17, 17, 0.5);
    outline: none;
    vertical-align: middle;
    color: #333333;
    font-family: "roboto-regular", sans-serif;
    font-size: 1.2rem;
    line-height: 3rem;
    max-width: 100%;
    background: #ffffff;
    -moz-transition: all 0.3s ease-in-out;
    -o-transition: all 0.3s ease-in-out;
    -webkit-transition: all 0.3s ease-in-out;
    -ms-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}

.shrink {
  min-height: 35px;
}
</style><nav class="navbar navbar-inverse navbar-fixed-top" style="z-index:2000;background:;box-shadow:0px 0px 1px #ffffff;">
 <div class="container"><div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="images/Untitled 2.png"
                style=" max-height: 100%;
    height: auto;
    width: auto9;"></a></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
   
               <ul class="nav navbar-nav navbar-right">
          <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php" style="color:#ffffff">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php?info=1#info" style="color:#ffffff">Events</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php?spo=2#cta" style="color:#ffffff">Sponsors</a>
                    </li>
                      <li>
                        <a class="page-scroll" href="http://www.aurganon.com/team.php" style="color:#ffffff">Team</a>
                    </li>
                                       <li class="active">
                        <a href="login.php" style=""><i class="icon-key"></i> LOGIN</a>
                    </li>
                    <li class="active">
                        <a  href="signup.php" style=""><i class="icon-users"></i> REGISTER</a>
                    </li>
<!--                     <li class="" style="font-size: 1rem;margin-top: 5px;line-height: 2rem;"> -->
<!--                         Registrations are <br> temporarily closed -->
<!--                     </li> -->
                                        
                   
      
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</div>
</nav><!-- /header -->   
<!DOCTYPE html>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7555171924828663",
    enable_page_level_ads: true
  });
</script>



<style>
#home.home-particles {
	background-image: url('images/aur.jpg')!important;
	background-size: cover;
	overflow: hidden;
}
.main-content-tablecell {
	display: table-cell;
	z-index: 700;
	padding-top: 50px;
}
.main-content-tablecell {
	display: table-cell;
	vertical-align: top;
	z-index: 700;
}
</style>
<section id="home" class="home-particles">
  <div class="shadow-overlay"></div>
  <div class="content-wrap-table">
    <div class="main-content-tablecell">
      <style>
.main-content-tablecell #counter {
margin-bottom: 0px;
}

a, a:visited {
color: #057f78;
-moz-transition: all 0.3s ease-in-out;
-o-transition: all 0.3s ease-in-out;
-webkit-transition: all 0.3s ease-in-out;
-ms-transition: all 0.3s ease-in-out;
transition: all 0.3s ease-in-out;
}
#info {
background: #FFFFFF;
background-image: url(../images/bg.jpg);
background-attachment: fixed;
background-repeat: no-repeat;
background-position: center;
-webkit-background-size: cover;
-moz-background-size: cover;
background-size: cover;
padding: 60px 0 9rem;
position: relative;
color: rgba(17, 17, 17, 0.7);
}
</style>
      <div class="row" >
        <div class="container" align="center" style="background:rgba(0, 0, 0, 0.74);padding:20px;">
          <center>
            <h1 style="font-size:35px;">21<sup>st</sup> September, 2017</h1>
            <h2 style="color:#ffffff;">National Level Technical Symposium</h2>
            <script>
	            var ele = document.getElementById('counter');
            	ele.style.visibility='hidden';
            
            	
            	// window.open("http://google.com", '_blank');
            </script>
            <!--<div id="counter" >-->
            	
            <!--  <div class="half"> <span style="font-size:90px;">30<sup>days</sup></span> <span style="font-size:90px;">23 <sup>hours</sup></span> </div>-->
            <!--  <div class="half"> <span style="font-size:90px;">50 <sup>mins</sup></span> <span style="font-size:90px;">33 <sup>secs</sup></span> </div>-->
            <!--</div>-->
            <div class="main-content-tablecell" style="padding-top: 10px;">
            	<img src="images/logoun.png" style="height:120px;">
              <h1 style="font-size:30px;">SRM University, Ramapuram campus</h1>
              <h1 style="font-size:20px;">Department Of Information Technology</h1>
              <h1 style="font-size:20px;">Presents</h1>
              <h1 style="font-size:35px;">Aurganon '17</h1>
              <script>
              	function openInNewTab(url) {
				  var win = window.open(url, '_blank');
				  win.focus();
				}
              </script>
              <p style="
    margin-bottom: 0px;
">
      
  
              	 <a onClick='openInNewTab("https://www.facebook.com/search/top/?q=%23lumos&ref=eyJzaWQiOiIwLjkwMzI5NTEyNjIyMDc0NzYiLCJxcyI6IkpUVkNKVEl5SlRJemNHOTNaWEoxY0NVeU1pVTFSQSIsImd2IjoiYmVlMDlmOTNmYTczMmNmYTU5YTFjYjZkOWY0NTBkMzg5MjQyNGU0OSJ9")'><font color="orange">#Lumos</font></a> </p>
           
                  
            <a href="https://play.google.com/store/apps/details?id=com.aurganonlite.android"><img src="https://storage.googleapis.com/support-kms-prod/D90D94331E54D2005CC8CEE352FF98ECF639" style="width:200px"></a><br>
           <br>
           </a> 
            <a href="#info" style="" class="button" style="letter-spacing:0rem;"><i class="fa fa-tasks" ></i> Browse Events</a>
            </div>
            <!--<a href="#info" style=""  style="letter-spacing:0rem;"><img src="images/browse.png" style="width:180px;"> -->
               
            <!-- /scroll-icon -->
          </center>
        </div>
        <!-- /twelve --> 
        
      </div>
      <!-- /row --> 
      
    </div>
    <!-- /main-content --> 
    
  </div>
  <!-- /content-wrap --> 
  
</section>
<!-- /home -->

<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script>
$(document).ready(function(){
	var obj = $('#home');
	
	var backgrounds = new Array(
		'url(imsges/slides/01.jpg)'
		'url(imsges/slides/01.jpg)'
		'url(imsges/slides/01.jpg)'
	
		// ,'url(images/flashvbat.jpg)'
	
        
	);
	
	var current = 0;
	
	function nextBackground() {
		current++;
		current = current % backgrounds.length;
		obj.css('background-image', backgrounds[current]);
	}
	setInterval(nextBackground, 10000);
	
	obj.css('background-image', backgrounds[0]);
});
</script>
<!-- info
================================================== -->

<!DOCTYPE html><section id="info" style="background-image:url('images/aur.jpg')!important;">
<!--<section id="info" style="background-image:url(images/bg.jpg);">-->
	
  <div class="info-overlay"></div>
  <center>
    <h1>EVENTS - Technical</h1>
  </center>
  <div class="row">
    <div class="col-twelve tabs-wrap" style="margin: 0rem 0;">
      <style>
#info .tabs-wrap .tab-content {
padding: 0rem 0;
}
#info .tabs-wrap ul.tab li.active {
    background: #151515;
    color: #FFFFFF;
    border: none;
}
#info .tabs-wrap ul.tab li:hover {
    background: rgba(255, 255, 255, 0.2);
    color: rgba(17, 17, 17, 0.8);
    box-shadow: 10px 10px 5px rgba(0,0,0,.5);
}
#info .tabs-wrap ul.tab li:last-child {
    margin-right: 0;
}
#info .tabs-wrap ul.tab li {
    display: inline-block;
    font-family: "roboto-black", sans-serif;
    text-transform: uppercase;
    background: transparent;
    font-size: 1.4rem;
    letter-spacing: .2rem;
    color: rgb(0, 0, 0);
    padding: .9rem 3rem;
    margin: 0 1rem 0 0;
    border: 1px solid rgb(0, 0, 0);
    cursor: pointer;
}
</style>
      <ul class="tab" style="margin: 0 0 0rem 0;">
       <a  href="http://www.aurganon.com/index.php?info=1#info" style="text-decoration:none;color:#fff;">
       	 <li  class="active"   style="margin: 0rem 0;"><i class="fa fa-laptop"></i><span>Technical</span></li></a>
       	 <a  href="http://www.aurganon.com/index.php?info=3#info" style="color:#fff;text-decoration:none;">
        <li  data-id="non"><i class="fa fa-pencil-square-o"></i><span>Non-technical</span></li></a>
        	 <a  href="http://www.aurganon.com/index.php?info=4#info" style="color:#fff;text-decoration:none;">  <li  data-id="non"><i class="fa fa-cloud"></i><span>Online Events</span></li></a>
       <!--	<li data-id="tab-subscribe"><i class="icon-newspaper"></i><span>Subscribe</span></li>	
<li data-id="tab-subscribe"><i class="icon-newspaper"></i><span>Subscribe</span></li> -->
        
      </ul>
      <!-- /tabs -->
      
      <div class="tab-container"> 
        <font style="color:red;background:#fff;">Registrations are Open</font><br>
     
        <!--<font style="color:#fff;background:rgba(0, 0, 0, 0.74);">*FREE events are covered in common registration fees of Rs 150.</font>-->
        <!-- tab content - about
================================================== -->
        <div id="tab-technical" class="tab-content">
          <div class="tab-entry">
            <div class="row tab-entry-intro">
              <div class="col-twelve with-bottom-line"> </div>
            </div>
            <!-- /tab-content-intro -->
            
            <div class="row about-content tab-entry-content">
              <div class="about-list block-1-3 block-s-1-2 block-tab-full">
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">O.W.L.</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;The ordinary wizarding level is a quiz competition on both technical and non-technical subjects.</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21751355_1922643114662759_7579393136404103101_n.jpg?oh=1f3c0eb5de62e028790cc76a6236b536&oe=5A44153E" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=QmRvcEJ2YVFxRklKWllFb1F5b2NuQT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=QmRvcEJ2YVFxRklKWllFb1F5b2NuQT09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">ROLLING THE DICE</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Motivational Talk</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="http://aurganon.com/images/events/talk.jpg" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=YjlBeEV2dGpMcTJ0TUhFV3o3a2loQT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=YjlBeEV2dGpMcTJ0TUhFV3o3a2loQT09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">PARSEL TONGUE</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Speaking the language of computers, an exciting event on coding and web designing</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21731290_1922062448054159_8985130282348085181_n.jpg?oh=44afbdaf65d6543f0cc3d506b0d1574c&oe=5A407ECA" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=Q0p3OWZ5QmhMT0YzUVRRajk5d2QrZz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=Q0p3OWZ5QmhMT0YzUVRRajk5d2QrZz09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">ALOHA-MORA</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Speaking the language of computers, an exciting event on coding and web designing.</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21740687_1922294254697645_2209040600706158448_n.jpg?oh=cbbaa2ec265bfcdc0e3a7043829d2a97&oe=5A5124B7" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=Q1p3aGFvbXc5WHltclVOVTkvaytFZz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=Q1p3aGFvbXc5WHltclVOVTkvaytFZz09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">DECIPHER</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Here it comes again, the game of keys and words is coming. The mystery behind secret codes are yet to be solved.<br>Are you up for the challenge...??</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-0/q81/s480x480/21463095_1922567608003643_1712275388504331400_n.jpg?oh=ef87da05100216e46f59d6f0b409f771&oe=5A5B894A" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=T1pYcktJakt5aUdsaTNGaDJJdnBydz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=T1pYcktJakt5aUdsaTNGaDJJdnBydz09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">WORKSHOP</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Digital India Workshop on Progressive Web App for Augmented Reality. </h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21743017_1927019017623417_7787624773337501007_n.jpg?oh=3079da6e31b20a414218e52f1e928378&oe=5A4B9070" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=cDdxa2phMkt2MGVHUFVkVmhXd3E5dz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=cDdxa2phMkt2MGVHUFVkVmhXd3E5dz09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <div class="bgrid item" style="
padding-bottom: 20px;
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6 ; border-color: #0513EA;
">
                    <div class="card-block">
                      <style>
.text-muted {
color: #080808;
}
</style>
                      <h4 class="card-title">QUILL & PARCHMENT</h4>
                      <h6 class="card-subtitle text-muted">&nbsp;Paving a way for the students to enlighten other with their knowledge through paper presentation.</h6>
                    </div>
                    <!--<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSPhIxhDkQNdYKpgeJWysNYfVwM9LEwUF6m7v53YGg7_7rYTDrl" alt="Card image">--> 
                    <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21743382_1921576538102750_8853606438349677822_n.jpg?oh=1d4fd5b3a7d3ed52176eced6171a7f8e&oe=5A14D0A6" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=eHlpRE5iR053SWVQTkwwR2ZLUFIyQT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> 

<a href="evereg.php?id=eHlpRE5iR053SWVQTkwwR2ZLUFIyQT09" class="button" style="background: #151515;color: #FFFFFF;border: none;" role="button">Register</a>
</div>
                  </div>
                </div>
                                <!-- /bgrid --> 
                
              </div>
              <!-- /about-list --> 
              
            </div>
            <!-- /row about-content --> 
            
          </div>
          <!-- /tab-entry --> 
          
        </div>
        <!-- /tab-about -->
        <div id="tab-non" class="tab-content">
          <div class="tab-entry">
            <div class="row tab-entry-intro">
              <div class="col-twelve with-bottom-line"> </div>
            </div>
            <!-- /tab-content-intro -->
            
            <div class="row about-content tab-entry-content">
              <div class="about-list block-1-3 block-s-1-2 block-tab-full">
                                <div class="bgrid item" style="padding-bottom: 20px; opacity:0.9; 
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6    ; border-color: #0513EA;  box-shadow: 10px 10px 5px #2B2B2B;">
                    <div class="card-block">
                      <h4 class="card-title">SUPER OVER </h4>
                      <h6 class="card-subtitle text-muted">Be a reaper, a catcher or a beater. Students will show their skills in the sports events.</h6>
                    </div>
                   <img src="http://aurganon.com/images/events/SuperOver.jpg" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=NE8xSDRQcXRFSmZONHlrUnBsQ2dPdz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> <a href="evereg.php?id=NE8xSDRQcXRFSmZONHlrUnBsQ2dPdz09" class="button" style="       background: #151515;
color: #FFFFFF;
border: none;" role="button">Register</a> </div>
                  </div>
                </div>
                                <div class="bgrid item" style="padding-bottom: 20px; opacity:0.9; 
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6    ; border-color: #0513EA;  box-shadow: 10px 10px 5px #2B2B2B;">
                    <div class="card-block">
                      <h4 class="card-title">QUIDDITCH CUP</h4>
                      <h6 class="card-subtitle text-muted">Be a reaper, a catcher or a beater. Students will show their skills in the sports events.</h6>
                    </div>
                   <img src="http://aurganon.com/images/events/quidich.jpg" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=dldmb2I5dTRrU29kU1JHajRoRWJTdz09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> <a href="evereg.php?id=dldmb2I5dTRrU29kU1JHajRoRWJTdz09" class="button" style="       background: #151515;
color: #FFFFFF;
border: none;" role="button">Register</a> </div>
                  </div>
                </div>
                                <div class="bgrid item" style="padding-bottom: 20px; opacity:0.9; 
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6    ; border-color: #0513EA;  box-shadow: 10px 10px 5px #2B2B2B;">
                    <div class="card-block">
                      <h4 class="card-title">TRIWIZARD TOURNAMENT</h4>
                      <h6 class="card-subtitle text-muted">Put the name in the Goblet of Fire, may the best in gaming win.</h6>
                    </div>
                   <img src="http://aurganon.com/images/events/triv.jpg" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=RFZjeHoxdFJFQWJVOVZjQjVObmtqQT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> <a href="evereg.php?id=RFZjeHoxdFJFQWJVOVZjQjVObmtqQT09" class="button" style="       background: #151515;
color: #FFFFFF;
border: none;" role="button">Register</a> </div>
                  </div>
                </div>
                                <div class="bgrid item" style="padding-bottom: 20px; opacity:0.9; 
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6    ; border-color: #0513EA;  box-shadow: 10px 10px 5px #2B2B2B;">
                    <div class="card-block">
                      <h4 class="card-title">HOGWART'S EXPRESS</h4>
                      <h6 class="card-subtitle text-muted">A new form of entertainment for the students to take part on spot.</h6>
                    </div>
                   <img src="http://aurganon.com/images/hogwart.jpg" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=NmszWHplVFdqMFRNaVZ6SklnZWh6QT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> <a href="evereg.php?id=NmszWHplVFdqMFRNaVZ6SklnZWh6QT09" class="button" style="       background: #151515;
color: #FFFFFF;
border: none;" role="button">Register</a> </div>
                  </div>
                </div>
                                <div class="bgrid item" style="padding-bottom: 20px; opacity:0.9; 
">
                  <div class="card card-outline-warning" style="background-color: #F6F6F6    ; border-color: #0513EA;  box-shadow: 10px 10px 5px #2B2B2B;">
                    <div class="card-block">
                      <h4 class="card-title">HORCRUX HUNT</h4>
                      <h6 class="card-subtitle text-muted">Just like potter, a treasure hunt for students to enlighten their minds</h6>
                    </div>
                   <img src="https://scontent.fmaa1-2.fna.fbcdn.net/v/t1.0-9/21751464_1921457921447945_1095870376194779796_n.jpg?oh=9de4f87b337d0ecfb4ebd612c80e17f6&oe=5A50314A" alt="Card image">
                    <div class="card-block">
                      <p class="card-text"></p>
                      <a href="aboutevent.php?id=TGxpVE5obzNWQS90dkhLQnhCSHd2QT09" class="button" style="background: #151515;
color: #FFFFFF;
border: none;">Know more</a> <a href="evereg.php?id=TGxpVE5obzNWQS90dkhLQnhCSHd2QT09" class="button" style="       background: #151515;
color: #FFFFFF;
border: none;" role="button">Register</a> </div>
                  </div>
                </div>
                                <!-- /bgrid --> 
                
              </div>
              <!-- /about-list --> 
              
            </div>
            <!-- /row about-content --> 
            
          </div>
          <!-- /tab-entry --> 
          
        </div>
      </div>
      <!-- /tab-container --> 
      
    </div>
    <!-- twelve --> 
  </div>
  <!-- row --> 
  
</section>
<!-- /info --> 

<!-- CTA Section
================================================== -->

</div>
<!-- footer
================================================== -->
<!DOCTYPE html>
    
<footer style="background:#222222;">
  <div class="social-wrap" style="background:#e9ab0c;">
    <div class="row">
      <ul class="footer-social-list">
      	<style>
      		footer .footer-social-list a:hover{
      			color:#222222;
      		}
      	</style>
        <li><a href="https://www.facebook.com/aurganon"> <i class="fa fa-facebook"></i><span>Facebook</span> </a></li>
        <li><a href="https://twitter.com/aurganon16"> <i class="fa fa-twitter"></i><span>Twitter</span> </a></li>
        <li><a href="https://www.instagram.com/aurganon/"> <i class="fa fa-instagram"></i><span>Instagram</span> </a></li>
        <li><a href="https://www.youtube.com/channel/UC4OOJFrzWzqrSNCyPZxJAfw"> <i class="fa fa-youtube"></i><span>Youtube</span> </a></li>
        <li><a href="https://www.linkedin.com/company/15092210"> <i class="fa fa-linkedin"></i><span>LinkedIn</span> </a></li>
      </ul>
    </div>
    <!-- /row --> 
  </div>
  
  <!--footer-start-->
  <div class="footer-bottom">
  	
    <div class="copyright" style="color:#ffffff;"> <span>©Copyright Department Of Information Technology SRM University Ramapuram Campus</span> <br>
      <span><i class="fa fa-code"></i> Developed by <a href="https://www.facebook.com/Project-Club-1579789532326643/" 
      style="color:#E9AB0C; font-weight:900">Project Club</a></span> </div>
  </div>
  <!-- /footer-end -->
  
  <div class="back-to-top" style="bottom: 31px;"> <a href="#top" class="smoothscroll"><span>Back to Top</span></a> </div>
</footer>
<div id="preloader">
  <div id="loader"></div>
  <!--<b>WELCOME!</b>-->
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style=" height: 50px;    padding: 0px 10px 0px 10px;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style="padding:10px;">Login</h4>
      </div>
      <div class="modal-body">
        <!--<p>Some text in the modal.</p>-->
        <form class="form-horizontal" method="POST" action="login.php">
          <div class="form-group" style="margin-bottom: 0px;">
            <div class="col-twelve col-full">
              <input type="email" class="form-control" name="uname" id="email" placeholder="Enter email">
            </div>
          </div>
          <div class="form-group" style="    margin-bottom: 0px;">
            <div class="col-twelve col-full">
              <input type="password" class="form-control" name="pwd" id="pwd" placeholder="Enter password">
            </div>
          </div>
          <div class="form-group" style="    margin-bottom: 0px;">
            <div class="col-twelve">
              <button type="submit" class="button" style="width:100%;">LOGIN</button>
            </div>
            <div class="col-twelve">
              <button type="button" class="button"  style="width:100%;">REGISTER</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="signup" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style=" height: 50px;    padding: 0px 10px 0px 10px;">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style="padding:10px;">Sign Up</h4>
      </div>
      <div class="modal-body">
        <!--<p>Some text in the modal.</p>-->
        <form class="form-horizontal">
          <div class="form-group" style="margin-bottom: 0px;">
            <div class="col-twelve col-full">
              <input type="text" class="form-control" id="name" placeholder="Enter Name">
            </div>
          </div>
          <div class="form-group" style="margin-bottom: 0px;">
            <div class="col-twelve col-full">
              <input type="email" class="form-control" id="email" placeholder="Enter email">
            </div>
          </div>
          <div class="form-group" style="    margin-bottom: 0px;">
            <div class="col-twelve col-full">
              <input type="password" class="form-control" id="pwd" placeholder="Enter password">
            </div>
          </div>
          <div class="form-group" style="    margin-bottom: 0px;">
            <div class="col-twelve">
              <button type="submit" class="button" style="width:100%;">LOGIN</button>
            </div>
            <div class="col-twelve">
              <button type="submit" class="button"  style="width:100%;">REGISTER</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div> 
<!-- Java Script
================================================== -->
<script src="js/classie.js"></script>
<!-- <script src="js/borderMenu.js"></script> -->
<script src="https://code.jquery.com/jquery-3.1.0.min.js"  integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s="   crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-2.1.3.min.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<!-- <script src="js/materialize.js"></script> -->
</body>
</html>
