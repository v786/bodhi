<br />
<b>Warning</b>:  fopen(/var/log/spamavoid/php_execution_block.log): failed to open stream: Permission denied in <b>/var/log/spamavoid/php_execution_block.php</b> on line <b>19</b><br />
<br />
<b>Warning</b>:  fwrite() expects parameter 1 to be resource, boolean given in <b>/var/log/spamavoid/php_execution_block.php</b> on line <b>20</b><br />
<br />
<b>Warning</b>:  fclose() expects parameter 1 to be resource, boolean given in <b>/var/log/spamavoid/php_execution_block.php</b> on line <b>21</b><br />
