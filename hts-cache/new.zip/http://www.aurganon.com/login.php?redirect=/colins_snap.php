<!--Code Indented-->

<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>Aurganon'17 - Login</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="css/bootstrap.min.css"> 
   <link rel="stylesheet" href="css/base.css">  
   <link rel="stylesheet" href="css/main.css">
   <link rel="stylesheet" href="css/vendor.css">
   
    
    

   <!-- script
   ================================================== -->
	<script src="js/modernizr.js"></script>
    <script src="js/particles.js"></script>
    <script src="js/particles.min.js"></script>
    

   <!-- favicons
	================================================== -->
	<link rel="icon" type="image/png" href="images/logo.png">
 <style>
      main {margin-top:55px;}
    </style>
   

</head>

<body id="top">

	<!-- header 
   ================================================== -->
   <!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
	var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/57d29d15311d6c5be06348be/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
<style>
.navbar {
   margin-bottom:0px;
}	
input{
    margin-bottom: 1rem;
}
input[type="email"], input[type="number"], input[type="search"], input[type="text"], input[type="tel"], input[type="url"], input[type="password"], textarea, select {
    display: block;
    height: 4rem;
    padding: 1.5rem 2rem;
    border: none;
    border-bottom: 1px solid rgba(17, 17, 17, 0.5);
    outline: none;
    vertical-align: middle;
    color: #333333;
    font-family: "roboto-regular", sans-serif;
    font-size: 1.2rem;
    line-height: 3rem;
    max-width: 100%;
    background: #ffffff;
    -moz-transition: all 0.3s ease-in-out;
    -o-transition: all 0.3s ease-in-out;
    -webkit-transition: all 0.3s ease-in-out;
    -ms-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}

.shrink {
  min-height: 35px;
}
</style><nav class="navbar navbar-inverse navbar-fixed-top" style="z-index:2000;background:;box-shadow:0px 0px 1px #ffffff;">
 <div class="container"><div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="images/Untitled 2.png"
                style=" max-height: 100%;
    height: auto;
    width: auto9;"></a></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
   
               <ul class="nav navbar-nav navbar-right">
          <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php" style="color:#ffffff">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php?info=1#info" style="color:#ffffff">Events</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="http://www.aurganon.com/index.php?spo=2#cta" style="color:#ffffff">Sponsors</a>
                    </li>
                      <li>
                        <a class="page-scroll" href="http://www.aurganon.com/team.php" style="color:#ffffff">Team</a>
                    </li>
                                       <li class="active">
                        <a href="login.php" style=""><i class="icon-key"></i> LOGIN</a>
                    </li>
                    <li class="active">
                        <a  href="signup.php" style=""><i class="icon-users"></i> REGISTER</a>
                    </li>
<!--                     <li class="" style="font-size: 1rem;margin-top: 5px;line-height: 2rem;"> -->
<!--                         Registrations are <br> temporarily closed -->
<!--                     </li> -->
                                        
                   
      
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</div>
</nav>   


   <!-- info
   ================================================== -->


   <!-- CTA Section
   ================================================== -->




	<section id="cta" style="background-image: url('images/bat.jpg');
			background-repeat: no-repeat;
   			background-size: 100% 100%;
	">
		<style>
			@media screen and (min-width: 400px){
[class*="col-x"] {
    float: none !important;
    clear: both !important;
    margin-left: 0;
    margin-right: 0;
    padding: 20px;
}}
@media screen and (max-width: 400px){
[class*="col-x"] {
    width: 100% !important;
    float: none !important;
    clear: both !important;
    margin-left: 0;
    margin-right: 0;
    padding: 15px;
}
	.cta-content
	{
		background:transparent;
	}
	
}

@media screen and (max-width: 600px){
[class*="col-x"] {
    padding: 0 10px;
}}
@media screen and (max-width: 768px){
[class*="col-x"] {
    padding: 0 15px;
}}
		</style>
	
		

   	<div class="container" style="max-width:600px;">

   		<div class="col-twelve cta-content" style="background-color: rgba(0, 0, 0, 0.82)">  

	     		<h2 class="h01">LOGIN</h2>

		      <p class="lead" style="color:#ffffff">
		      Login To Your Account
				<!--Get <span>here</span>  <span></span>. -->
				<!-- Simply type	the promocode in the box labeled “Promo Code” when placing your order. -->	
				</p>

				<div class="action">
				 <form class="form-horizontal" method="post">
  <div class="form-group" style="margin-bottom: 0px;color:#fff">
  
    <div class="col-x col-full">
      <input type="email" class="form-control" name="uname" id="email" placeholder="Enter email" autocomplete="off">

      <input type="password" class="form-control" name="pwd" id="pwd" placeholder="Enter password"  autocomplete="off">

       <button type="submit" class="button" style="width:100%;">LOGIN</button>
      <!--<a href="signup.php"><button class="button" action="signup.php" style="width:100%;">REGISTER</button></a>-->
      Not a member yet?<a href="signup.php" style="color:#fff"> <u> Join us!</u></a>
        <!--<a href="signup.php"><button class="button" action="signup.php" style="width:100%;">REGISTER</button></a>-->
      <!--<a class="button" href="forgotkeyreq.php" role="button" style="width:100%;">Forgot Password ?</a>-->
  </div>
  </div>
  </form>

					
					
			       
		      </div>		     	

   		</div>

   	</div> <!-- /cta-content -->

   </section> <!-- /cta --> 

   <!-- footer
   ================================================== -->
<!DOCTYPE html>
    
<footer style="background:#222222;">
  <div class="social-wrap" style="background:#e9ab0c;">
    <div class="row">
      <ul class="footer-social-list">
      	<style>
      		footer .footer-social-list a:hover{
      			color:#222222;
      		}
      	</style>
        <li><a href="https://www.facebook.com/aurganon"> <i class="fa fa-facebook"></i><span>Facebook</span> </a></li>
        <li><a href="https://twitter.com/aurganon16"> <i class="fa fa-twitter"></i><span>Twitter</span> </a></li>
        <li><a href="https://www.instagram.com/aurganon/"> <i class="fa fa-instagram"></i><span>Instagram</span> </a></li>
        <li><a href="https://www.youtube.com/channel/UC4OOJFrzWzqrSNCyPZxJAfw"> <i class="fa fa-youtube"></i><span>Youtube</span> </a></li>
        <li><a href="https://www.linkedin.com/company/15092210"> <i class="fa fa-linkedin"></i><span>LinkedIn</span> </a></li>
      </ul>
    </div>
    <!-- /row --> 
  </div>
  
  <!--footer-start-->
  <div class="footer-bottom">
  	
    <div class="copyright" style="color:#ffffff;"> <span>©Copyright Department Of Information Technology SRM University Ramapuram Campus</span> <br>
      <span><i class="fa fa-code"></i> Developed by <a href="https://www.facebook.com/Project-Club-1579789532326643/" 
      style="color:#E9AB0C; font-weight:900">Project Club</a></span> </div>
  </div>
  <!-- /footer-end -->
  
  <div class="back-to-top" style="bottom: 31px;"> <a href="#top" class="smoothscroll"><span>Back to Top</span></a> </div>
</footer>

   <div id="preloader"> 
    	<div id="loader"></div>
   </div> 

   <!-- Java Script
   ================================================== --> 
  <script src="js/classie.js"></script>
	<script src="js/borderMenu.js"></script>
     <script   src="https://code.jquery.com/jquery-3.1.0.min.js"  integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s="   crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-2.1.3.min.js"></script>
   <script src="js/plugins.js"></script>
   <script src="js/main.js"></script>
    <script src="js/materialize.js"></script>
</body>

</html>